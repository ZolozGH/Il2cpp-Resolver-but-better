// ReSharper disable CppUnusedIncludeDirective
#include "includes.h"
#include "Rendering.hpp"
#include "Font.h"
#include "sdk.h"
#include "Menu.h"
#include "Functions.h"
#include "kiero/minhook/include/MinHook.h"
#include "il2cpp_resolver.hpp"
#include "Lists.hpp"
#include "Callback.hpp"
#include <Utils/VFunc.hpp>
#include <iostream>
#include <PaternScan.hpp>
#include <intrin.h>
#include <thread>
#include <mutex>
#define sqrt(x) ((x) < 0 ? -1 : (x) * (x))
#define PI 3.14259
extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

#pragma region JUNK

Present oPresent;
HWND window = NULL;
WNDPROC oWndProc;
ID3D11Device* pDevice = NULL;
ID3D11DeviceContext* pContext = NULL;
ID3D11RenderTargetView* mainRenderTargetView;
bool init = false;
static DWORD lastShotTime = 0;
static DWORD lasttick = 0;
UnityEngine_Shader_o* ChamsShader;

void initvars() {
	if (IL2CPP::Initialize(true)) {
		// Initialization successful
	}
	else {
		exit(0);
	}
	sdk::Base = (uintptr_t)GetModuleHandleA(NULL);
	sdk::GameAssembly = (uintptr_t)GetModuleHandleA("GameAssembly.dll");
	sdk::UnityPlayer = (uintptr_t)GetModuleHandleA("UnityPlayer.dll");
}

void InitImGui() {
	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO();
	io.ConfigFlags = ImGuiConfigFlags_NoMouseCursorChange;
	ImGui_ImplWin32_Init(window);
	ImGui_ImplDX11_Init(pDevice, pContext);
}

LRESULT __stdcall WndProc(const HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	if (ImGui_ImplWin32_WndProcHandler(hWnd, uMsg, wParam, lParam))
		return true;
	return CallWindowProcA(oWndProc, hWnd, uMsg, wParam, lParam);
}



bool Sigs() {
	return true;
}




#pragma endregion


namespace UTIL
{

		std::vector<Unity::CComponent*> foreach_Component_in_FindObjectOfType(const char* ClassName)
		{
			std::vector<Unity::CComponent*> ComponentList;
			auto list = Unity::Object::FindObjectsOfType<Unity::CComponent>(ClassName);
			if (!list || list->m_uMaxLength <= 0) {
				return ComponentList; 
			}

			const DWORD timeSlice = 5;
			DWORD startTime = GetTickCount64(); 

			for (int i = 0; i < list->m_uMaxLength; i++)
			{
				if (!list->operator[](i) || list->operator[](i)->IsDestroyed()) {
					continue;
				}

				auto head = list->operator[](i);
				ComponentList.push_back(head);

				DWORD currentTime = GetTickCount64();
				if (currentTime - startTime >= timeSlice) {
					break;
				}
			}

			return ComponentList;
		} 
		bool Shader(Unity::CGameObject* obj, const Unity::Color chams_color = Unity::Color(255, 255, 255, 1)) {
			auto RenderList = obj->GetComponentsInChildren<Unity::CRenderer*>("UnityEngine.Renderer");
			if (!RenderList || RenderList->m_uMaxLength == 0) {
				return false;
			}
			Unity::CShader* GameShader = Unity::Shader::Find(IL2CPP::String::New("GUI/Text Shader"));
			if (!GameShader) {
				return false; 
			}
			int renderListLength = RenderList->m_uMaxLength;
			for (int t = 0; t < renderListLength; ++t) {
				Unity::CRenderer* renderComponent = RenderList->operator[](t);
				if (!renderComponent->GetPropertyValue<bool>("enabled")) {
					continue;
				}
				Unity::CMaterial* material = renderComponent->GetMaterial();
				if (!material) {
					continue; 
				}
				material->SetShader(GameShader);
				material->SetPropertyValue<Unity::Color>("color", chams_color);
			}

			return true; 
		}
		bool DumpShaderNames(Unity::CGameObject* obj) {
			auto RenderList = obj->GetComponentsInChildren<Unity::CRenderer*>("UnityEngine.Renderer");
			if (!RenderList || RenderList->m_uMaxLength == 0) return false;


			int renderListLength = RenderList->m_uMaxLength;
			for (int t = 0; t < renderListLength; ++t) {
				Unity::CRenderer* renderComponent = RenderList->operator[](t);
				if (!renderComponent) continue;
				if (!renderComponent->GetPropertyValue<bool>("enabled")) continue;
				Unity::CMaterial* material = renderComponent->GetMaterial();
				if (!material) continue;
					std::cout << material->GetShader()->GetShaderName();
			}

			return true;

		}
		Unity::CGameObject* CreateGameObject(Unity::GameObject::m_ePrimitiveType primtype, Unity::Vector3 pos, Unity::Vector3 Size)
		{
			Unity::CGameObject* Cube = Unity::GameObject::CreatePrimitive(primtype);
			if (!Cube) return nullptr;
			Cube->GetTransform()->SetLocalPosition(pos);
			Cube->GetTransform()->SetLocalScale(Size);
			return Cube;
		}


		std::string GetFullGameObjectName(Unity::CGameObject* gameObject) {
			std::string fullName = gameObject->GetName()->ToString();
			Unity::CTransform* parent = gameObject->GetTransform()->GetParent();

			while (parent) {
				fullName = parent->CallMethodSafe<Unity::CGameObject*>("get_gameObject")->GetName()->ToString() + "/" + fullName;
				parent = parent->GetParent();
			}
			return fullName;
		}
		void DumpObjectsChildren(Unity::CGameObject* gameObject, const std::string& parentName = "", bool dumpComponents = true) {
			if (!gameObject) return;
			std::string fullName = GetFullGameObjectName(gameObject);

			if (parentName.empty()) {
				std::cout << "Dumping GameObject Children For: " << fullName << std::endl;
			}

			if (dumpComponents) {
				std::vector<std::string> components = Dumper::DumpClassesString(fullName);  // Dump the components of the GameObject
				std::cout << "  Components of " << fullName << ":" << std::endl;
				for (const std::string& component : components) {
					std::cout << "    " << component << std::endl;
				}
			}

			std::vector<Unity::CGameObject*> children = gameObject->GetTransform()->GetChildren();
			for (auto* child : children) {
				if (child) {
					std::string childName = child->GetName()->ToString();
					std::string childFullName = fullName + "/" + childName;
					std::cout << "  Child: " << childFullName << std::endl;
					DumpObjectsChildren(child, childFullName, dumpComponents);
				}
			}
		}
		void DumpObjectsChildrenFromComponent(Unity::CComponent* obj, bool dumpComponents = true) {
			Unity::CGameObject* gameObject = obj->GetGameObject();
			DumpObjectsChildren(gameObject, "", dumpComponents);
		}
}





void TheCheese()
{
	PlayerList.clear();
	PlayerList = UTIL::foreach_Component_in_FindObjectOfType("UnityEngine.CharacterController"); // Get Player class here namespace.Class
	if (PlayerList.empty()) return;

	for (auto* player : PlayerList)
	{
		if (!player)
			continue; 

			if (vars::Test)
			{
				UTIL::DumpObjectsChildrenFromComponent(player);
				vars::Test = !vars::Test;
			}
			if (vars::timething == true) {
				Unity::Time::SetTimeScale(vars::GameSpeed);
			}

	}
}


void renderloop()
{
	static DWORD lastUpdateTime = GetTickCount64(); // at some point replace with delta time
	const DWORD loopInterval = 5;

	DWORD currentTime = GetTickCount64();
	if (currentTime - lastUpdateTime < loopInterval) {
		return; 
	}

	lastUpdateTime = currentTime;

	if (!vars::initil2cpp) {
		return; 
	}
	TheCheese();
}


#pragma region UiStart
HRESULT __stdcall hkPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags)
{
	void* m_pThisThread = IL2CPP::Thread::Attach(IL2CPP::Domain::Get());

	if (!init)
	{
		if (SUCCEEDED(pSwapChain->GetDevice(__uuidof(ID3D11Device), (void**)&pDevice)))
		{
			pDevice->GetImmediateContext(&pContext);
			DXGI_SWAP_CHAIN_DESC sd;
			pSwapChain->GetDesc(&sd);
			window = sd.OutputWindow;
			ID3D11Texture2D* pBackBuffer;
			pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)&pBackBuffer);
			pDevice->CreateRenderTargetView(pBackBuffer, NULL, &mainRenderTargetView);
			pBackBuffer->Release();
			oWndProc = (WNDPROC)SetWindowLongPtr(window, GWLP_WNDPROC, (LONG_PTR)WndProc);
			InitImGui();
			ImGui::GetIO().Fonts->AddFontDefault();
			ImFontConfig font_cfg;
			font_cfg.GlyphExtraSpacing.x = 1.2;
			gameFont = ImGui::GetIO().Fonts->AddFontFromMemoryTTF(TTSquaresCondensedBold, 14, 14, &font_cfg);
			ImGui::GetIO().Fonts->AddFontDefault();
			init = true;
		}

		else
			return oPresent(pSwapChain, SyncInterval, Flags);
	}

	pContext->RSGetViewports(&vars::vps, &vars::viewport);
	vars::screen_size = { vars::viewport.Width, vars::viewport.Height };
	vars::screen_center = { vars::viewport.Width / 2.0f, vars::viewport.Height / 2.0f };

	auto begin_scene = [&]() {
		ImGui_ImplDX11_NewFrame();
		ImGui_ImplWin32_NewFrame();
		ImGui::NewFrame();
		};

	auto end_scene = [&]() {
		ImGui::Render();
		};

	begin_scene();



	

	POINT mousePos;
	GetCursorPos(&mousePos);
	ScreenToClient(window, &mousePos);

	if (show_menu)
	{
		DrawMenu();
	}
		try
		{
			renderloop();
		}
		catch (...) {}
		
	end_scene();

	if (GetAsyncKeyState(VK_INSERT) & 1)
	{
		show_menu = !show_menu;
		ImGui::GetIO().MouseDrawCursor = show_menu;
	}

	if (GetKeyState(VK_END) & 1)
	{
		MH_DisableHook(MH_ALL_HOOKS);
		MH_Uninitialize();
		show_menu = false;
	}

	pContext->OMSetRenderTargets(1, &mainRenderTargetView, NULL);
	ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

	IL2CPP::Thread::Detach(m_pThisThread);

	return oPresent(pSwapChain, SyncInterval, Flags);
}

void CreateConsole() {
	AllocConsole();
	AttachConsole(GetCurrentProcessId());
	FILE* f;
	freopen_s(&f, "CONOUT$", "w", stdout);
}

void initchair()
{
	initvars();
	IL2CPP::Callback::Initialize();

	//find_sigs();
	//EnableHooks();

	CreateConsole();
	system("cls");




	printf("_______________________________________________ Sigs*\n");
	Sigs();
	printf("\n_______________________________________________ Hooks*\n");
	kiero::bind(8, (void**)&oPresent, hkPresent);
	//	CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)Player_Cache, NULL, NULL, NULL);
}

DWORD WINAPI MainThread(LPVOID lpReserved)
{
	bool init_hook = false;
	do
	{
		if (kiero::init(kiero::RenderType::D3D11) == kiero::Status::Success)
		{
			initchair();
			init_hook = true;
			vars::initil2cpp = true;
		}
	} while (!init_hook);
	return TRUE;
}

BOOL WINAPI DllMain(HMODULE mod, DWORD reason, LPVOID lpReserved)
{
	if (reason == 1)
	{
		DisableThreadLibraryCalls(mod);
		CreateThread(nullptr, 0, MainThread, mod, 0, nullptr);
	}
	return TRUE;
}

#pragma endregion
