#pragma once
std::vector<Unity::CComponent*> PlayerList(NULL);
std::vector<Unity::CComponent*> Flag(NULL);