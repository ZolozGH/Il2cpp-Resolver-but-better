#pragma once

#include <Windows.h>
#include <stdint.h>

// Function pointer types
typedef void (*Il2CppMethodPointer)();

// Forward declarations for Il2Cpp types
struct MethodInfo;
struct Il2CppClass_;

// VirtualInvokeData struct for virtual function pointers
struct VirtualInvokeData {
    Il2CppMethodPointer methodPtr; // Function pointer
    const MethodInfo* method;      // Associated method information
};

// Il2CppType struct for type representation
struct Il2CppType {
    void* data;
    unsigned int bits;
};

// Base object for Il2Cpp objects
struct Il2CppObject_ {
    Il2CppClass_* klass;
    void* monitor;
};

// Il2CppRGCTXData union for runtime generic context data
union Il2CppRGCTXData {
    void* rgctxDataDummy;
    const MethodInfo* method;
    const Il2CppType* type;
    Il2CppClass_* klass;
};

// Struct for runtime interface offset pairs
struct Il2CppRuntimeInterfaceOffsetPair {
    Il2CppClass_* interfaceType;
    int32_t offset;
};

// Il2CppClass__1_ struct for type metadata and hierarchy
struct Il2CppClass__1_ {
    void* image;
    void* gc_desc;
    const char* name;
    const char* namespaze;
    Il2CppType* byval_arg;
    Il2CppType* this_arg;
    Il2CppClass_* element_class;
    Il2CppClass_* castClass;
    Il2CppClass_* declaringType;
    Il2CppClass_* parent;
    void* generic_class;
    void* typeMetadataHandle;
    void* interopData;
    Il2CppClass_* klass;
    void* fields;
    void* events;
    void* properties;
    void* methods;
    Il2CppClass_** nestedTypes;
    Il2CppClass_** implementedInterfaces;
    Il2CppRuntimeInterfaceOffsetPair* interfaceOffsets;
};

// Il2CppClass__2_ struct for runtime and static data
struct Il2CppClass__2_ {
    Il2CppClass_** typeHierarchy;
    void* unity_user_data;
    uint32_t initializationExceptionGCHandle;
    uint32_t cctor_started;
    uint32_t cctor_finished;
    size_t cctor_thread;
    void* genericContainerHandle;
    uint32_t instance_size;
    uint32_t actualSize;
    uint32_t element_size;
    int32_t native_size;
    uint32_t static_fields_size;
    uint32_t thread_static_fields_size;
    int32_t thread_static_fields_offset;
    uint32_t flags;
    uint32_t token;
    uint16_t method_count;
    uint16_t property_count;
    uint16_t field_count;
    uint16_t event_count;
    uint16_t nested_type_count;
    uint16_t vtable_count;
    uint16_t interfaces_count;
    uint16_t interface_offsets_count;
    uint8_t typeHierarchyDepth;
    uint8_t genericRecursionDepth;
    uint8_t rank;
    uint8_t minimumAlignment;
    uint8_t naturalAligment;
    uint8_t packingSize;
    uint8_t bitflags1;
    uint8_t bitflags2;
};

// Complete Il2CppClass structure
struct Il2CppClass_ {
    Il2CppClass__1_ _1;
    void* static_fields;
    Il2CppRGCTXData* rgctx_data;
    Il2CppClass__2_ _2;
    VirtualInvokeData vtable[255];
};

// Array bounds for Il2Cpp arrays
typedef uintptr_t il2cpp_array_size_t;
typedef int32_t il2cpp_array_lower_bound_t;
struct Il2CppArrayBounds__ {
    il2cpp_array_size_t length;
    il2cpp_array_lower_bound_t lower_bound;
};

// MethodInfo structure
typedef void (*InvokerMethod)(Il2CppMethodPointer, const MethodInfo*, void*, void**, void*);
struct MethodInfo {
    Il2CppMethodPointer methodPointer;
    Il2CppMethodPointer virtualMethodPointer;
    InvokerMethod invoker_method;
    const char* name;
    Il2CppClass_* klass;
    const Il2CppType* return_type;
    const Il2CppType** parameters;
    union {
        const Il2CppRGCTXData* rgctx_data;
        const void* methodMetadataHandle;
    };
    union {
        const void* genericMethod;
        const void* genericContainerHandle;
    };
    uint32_t token;
    uint16_t flags;
    uint16_t iflags;
    uint16_t slot;
    uint8_t parameters_count;
    uint8_t bitflags;
};

// UnityEngine Object base structure
struct __declspec(align(8)) UnityEngine_Object_Fields {
    intptr_t m_CachedPtr;
};

// Virtual table for UnityEngine Object
struct UnityEngine_Object_VTable {
    VirtualInvokeData _0_Equals;
    VirtualInvokeData _1_Finalize;
    VirtualInvokeData _2_GetHashCode;
    VirtualInvokeData _3_ToString;
};

// UnityEngine Object class definition
struct UnityEngine_Object_c {
    Il2CppClass__1_ _1;
    struct UnityEngine_Object_StaticFields* static_fields;
    Il2CppRGCTXData* rgctx_data;
    Il2CppClass__2_ _2;
    UnityEngine_Object_VTable vtable;
};

// UnityEngine Object instance
struct UnityEngine_Object_o {
    UnityEngine_Object_c* klass;
    void* monitor;
    UnityEngine_Object_Fields fields;
};

// Static fields for UnityEngine Object
struct UnityEngine_Object_StaticFields {
    int32_t OffsetOfInstanceIDInCPlusPlusObject;
};

// UnityEngine Shader structure
struct UnityEngine_Shader_Fields : UnityEngine_Object_Fields {};

// Virtual table for UnityEngine Shader
struct UnityEngine_Shader_VTable {
    VirtualInvokeData _0_Equals;
    VirtualInvokeData _1_Finalize;
    VirtualInvokeData _2_GetHashCode;
    VirtualInvokeData _3_ToString;
};

// UnityEngine Shader class definition
struct UnityEngine_Shader_c {
    Il2CppClass__1_ _1;
    void* static_fields;
    Il2CppRGCTXData* rgctx_data;
    Il2CppClass__2_ _2;
    UnityEngine_Shader_VTable vtable;
};

// UnityEngine Shader instance
struct UnityEngine_Shader_o {
    UnityEngine_Shader_c* klass;
    void* monitor;
    UnityEngine_Shader_Fields fields;
};

// UnityEngine Material structure
struct UnityEngine_Material_Fields : UnityEngine_Object_Fields {};

// Virtual table for UnityEngine Material
struct UnityEngine_Material_VTable {
    VirtualInvokeData _0_Equals;
    VirtualInvokeData _1_Finalize;
    VirtualInvokeData _2_GetHashCode;
    VirtualInvokeData _3_ToString;
};

// UnityEngine Material class definition
struct UnityEngine_Material_c {
    Il2CppClass__1_ _1;
    void* static_fields;
    Il2CppRGCTXData* rgctx_data;
    Il2CppClass__2_ _2;
    UnityEngine_Material_VTable vtable;
};

// UnityEngine Material instance
struct UnityEngine_Material_o {
    UnityEngine_Material_c* klass;
    void* monitor;
    UnityEngine_Material_Fields fields;
};

struct UnityEngine_Component_Fields : UnityEngine_Object_Fields {
};
struct UnityEngine_Component_VTable {
    VirtualInvokeData _0_Equals;
    VirtualInvokeData _1_Finalize;
    VirtualInvokeData _2_GetHashCode;
    VirtualInvokeData _3_ToString;
};
struct UnityEngine_Component_c {
    Il2CppClass__1_ _1;
    void* static_fields;
    Il2CppRGCTXData* rgctx_data;
    Il2CppClass__2_ _2;
    UnityEngine_Component_VTable vtable;
};
struct UnityEngine_Component_o {
    UnityEngine_Component_c* klass;
    void* monitor;
    UnityEngine_Component_Fields fields;
};

struct __declspec(align(8)) System_Delegate_Fields {
    intptr_t method_ptr;
    intptr_t invoke_impl;
    Il2CppObject_* m_target;
    intptr_t method;
    intptr_t delegate_trampoline;
    intptr_t extra_arg;
    intptr_t method_code;
    intptr_t interp_method;
    intptr_t interp_invoke_impl;
    struct System_Reflection_MethodInfo_o* method_info;
    struct System_Reflection_MethodInfo_o* original_method_info;
    struct System_DelegateData_o* data;
    bool method_is_virtual;
};
struct System_Delegate_VTable {
    VirtualInvokeData _0_Equals;
    VirtualInvokeData _1_Finalize;
    VirtualInvokeData _2_GetHashCode;
    VirtualInvokeData _3_ToString;
    VirtualInvokeData _4_unknown;
    VirtualInvokeData _5_unknown;
    VirtualInvokeData _6_Clone;
    VirtualInvokeData _7_GetMethodImpl;
    VirtualInvokeData _8_GetObjectData;
    VirtualInvokeData _9_GetInvocationList;
    VirtualInvokeData _10_CombineImpl;
    VirtualInvokeData _11_RemoveImpl;
};
struct System_Delegate_c {
    Il2CppClass__1_ _1;
    void* static_fields;
    Il2CppRGCTXData* rgctx_data;
    Il2CppClass__2_ _2;
    System_Delegate_VTable vtable;
};
struct System_Delegate_o {
    System_Delegate_c* klass;
    void* monitor;
    System_Delegate_Fields fields;
};


struct System_MulticastDelegate_Fields : System_Delegate_Fields {
    struct System_Delegate_array* delegates;
};
struct System_MulticastDelegate_VTable {
    VirtualInvokeData _0_Equals;
    VirtualInvokeData _1_Finalize;
    VirtualInvokeData _2_GetHashCode;
    VirtualInvokeData _3_ToString;
    VirtualInvokeData _4_unknown;
    VirtualInvokeData _5_unknown;
    VirtualInvokeData _6_Clone;
    VirtualInvokeData _7_GetMethodImpl;
    VirtualInvokeData _8_GetObjectData;
    VirtualInvokeData _9_GetInvocationList;
    VirtualInvokeData _10_CombineImpl;
    VirtualInvokeData _11_RemoveImpl;
};
struct System_MulticastDelegate_c {
    Il2CppClass__1_ _1;
    void* static_fields;
    Il2CppRGCTXData* rgctx_data;
    Il2CppClass__2_ _2;
    System_MulticastDelegate_VTable vtable;
};
struct System_MulticastDelegate_o {
    System_MulticastDelegate_c* klass;
    void* monitor;
    System_MulticastDelegate_Fields fields;
};


struct UnityEngine_GUI_WindowFunction_Fields : System_MulticastDelegate_Fields {
};
struct UnityEngine_GUI_WindowFunction_VTable {
    VirtualInvokeData _0_Equals;
    VirtualInvokeData _1_Finalize;
    VirtualInvokeData _2_GetHashCode;
    VirtualInvokeData _3_ToString;
    VirtualInvokeData _4_unknown;
    VirtualInvokeData _5_unknown;
    VirtualInvokeData _6_Clone;
    VirtualInvokeData _7_GetMethodImpl;
    VirtualInvokeData _8_GetObjectData;
    VirtualInvokeData _9_GetInvocationList;
    VirtualInvokeData _10_CombineImpl;
    VirtualInvokeData _11_RemoveImpl;
    VirtualInvokeData _12_Invoke;
};
struct UnityEngine_GUI_WindowFunction_c {
    Il2CppClass__1_ _1;
    void* static_fields;
    Il2CppRGCTXData* rgctx_data;
    Il2CppClass__2_ _2;
    UnityEngine_GUI_WindowFunction_VTable vtable;
};
struct UnityEngine_GUI_WindowFunction_o {
    UnityEngine_GUI_WindowFunction_c* klass;
    void* monitor;
    UnityEngine_GUI_WindowFunction_Fields fields;
};
struct __declspec(align(8)) UnityEngine_GUI_Scope_Fields {
    bool m_Disposed;
};

