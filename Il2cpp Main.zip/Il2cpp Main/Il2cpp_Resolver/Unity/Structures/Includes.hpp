#pragma once
#include "il2cpp.hpp"
#include "il2cppArray.hpp"
#include "il2cppDictionary.hpp"

#include "Engine.hpp"
#include "System_String.hpp"