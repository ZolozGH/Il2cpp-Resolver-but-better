#include "../../Includes.hpp"
// C+P Ready Template

namespace Unity
{
	STime TimeFunctions;

	namespace Time
	{
		void Initialize()
		{
			IL2CPP::SystemTypeCache::Initializer::Add("UnityEngine.Time");
			TimeFunctions.m_pSetTimeScale = IL2CPP::ResolveCall("UnityEngine.Time::set_timeScale");
		}
		void SetTimeScale(float value)
		{
			void (UNITY_CALLING_CONVENTION t)(float);
			reinterpret_cast<decltype(t)>(TimeFunctions.m_pSetTimeScale)(value);
		}
	}
}