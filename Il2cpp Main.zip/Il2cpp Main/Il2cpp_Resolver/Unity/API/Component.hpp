#pragma once
#include <Unity/API/Object.hpp>

namespace Unity
{
	struct SComponentFunctions
	{
		void* m_pGetGameObject = nullptr;
		void* m_pGetTransform = nullptr;
		void* m_CachedPtrs = nullptr;
		void* m_pGetComponent = nullptr;
	};
	extern SComponentFunctions ComponentFunctions;

	class CComponent : public CObject
	{
	public:
		CGameObject* GetGameObject()
		{
			return reinterpret_cast<CGameObject*(UNITY_CALLING_CONVENTION)(void*)>(ComponentFunctions.m_pGetGameObject)(this);
		}

		CTransform* GetTransform()
		{
			return reinterpret_cast<CTransform*(UNITY_CALLING_CONVENTION)(void*)>(ComponentFunctions.m_pGetTransform)(this);
		}
		CComponent* GetComponent(Unity::il2cppObject* type) // has to hav e Component arg class collider : Component
		{
			return reinterpret_cast<CComponent*(UNITY_CALLING_CONVENTION)(void*, Unity::il2cppObject*)>(ComponentFunctions.m_pGetComponent)(this, type);
		}
	

		void* m_CachedPtrss;
		bool IsDestroyed() const {
			if (this == nullptr) {
				return true; // Null pointer means it's destroyed
			}

			// Unity objects often have an `m_CachedPtr` or similar field
			// that indicates whether they point to a valid Unity object.
			if (this->m_CachedPtrss == nullptr) {
				return true; // No valid memory pointer means destroyed
			}

			return false; // Object is valid
		}
		
	};

	namespace Component
	{
		void Initialize();
	}
}