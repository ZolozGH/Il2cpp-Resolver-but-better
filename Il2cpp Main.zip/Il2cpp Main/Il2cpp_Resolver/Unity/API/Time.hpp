#pragma once
#include "../Unity_Classes.h"
// C+P Ready Template

namespace Unity
{

	struct STime
	{
		void* m_pSetTimeScale = nullptr;
		void* m_pGetDeltaTime = nullptr;
	};
	extern STime TimeFunctions;

	class CTime : public IL2CPP::CClass
	{
	public:
		
	};

	namespace Time
	{
		void Initialize();
		void SetTimeScale(float value);
		//float* GetDeltaTime(float value);
	}
}