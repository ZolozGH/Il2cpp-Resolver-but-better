#pragma once
#include "../Unity_Classes.h"
// C+P Ready Template

namespace Unity
{
	
	struct SShader
	{
		void* m_pFind = nullptr;
		uintptr_t FindShader = 0x0;
	};
	extern SShader ShaderFunctions;

	class CShader : public IL2CPP::CClass
	{
	public:
		std::string GetShaderName()
		{
			return this->CallMethodSafe<Unity::System_String*>("get_name")->ToString();
		}
		
		
	};

	namespace Shader
	{

		void Initialize();
		Unity::CShader* Find(Unity::System_String* name);
	}
}