#pragma once
// C+P Ready Template

namespace Unity
{
	struct SLineRenderer
	{
		void* m_pSetPosition = nullptr;
		void* m_pSetPositionCount = nullptr;
		void* m_pSetStartWidth = nullptr;
		void* m_pSetEndWidth = nullptr;
		void* m_pSetStartColor = nullptr;
		void* m_pSetEndColor = nullptr;
		void* m_pGetPosition = nullptr;

	};
	extern SLineRenderer LineRendererFunctions;


	class CLineRenderer  : public IL2CPP::CClass
	{
	public:
		void SetPosition(int index, Vector3 position)
		{
			reinterpret_cast<void(UNITY_CALLING_CONVENTION)(void*, int, Vector3)>(LineRendererFunctions.m_pSetPosition)(this, index,position);
		}
		
		Vector3 GetPosition(int index)
		{
			Vector3 vRet;
			reinterpret_cast<void(UNITY_CALLING_CONVENTION)(void*,int, Vector3&)>(LineRendererFunctions.m_pGetPosition)(this,index, vRet);
			return vRet;
		}

		void SetPositionCount(int index)
		{
			reinterpret_cast<void(UNITY_CALLING_CONVENTION)(void*, int)>(LineRendererFunctions.m_pSetPositionCount)(this, index);
		}
		void SetStartWidth(float start)
		{
			reinterpret_cast<void(UNITY_CALLING_CONVENTION)(void*, float)>(LineRendererFunctions.m_pSetStartWidth)(this, start);
		}
		void SetEndWidth(float end)
		{
			reinterpret_cast<void(UNITY_CALLING_CONVENTION)(void*, float)>(LineRendererFunctions.m_pSetEndWidth)(this, end);
		}
		
	};

	namespace LineRenderer
	{
		void Initialize();
	}
}