#include "../../Includes.hpp"
// C+P Ready Template

namespace Unity
{
	SLineRenderer LineRendererFunctions;

	namespace LineRenderer
	{
		void Initialize()
		{
			IL2CPP::SystemTypeCache::Initializer::Add(UNITY_LINERENDERER_CLASS);
			LineRendererFunctions.m_pSetPosition = IL2CPP::ResolveCall(UNITY_LINERENDERER_SETPOSITION);
			LineRendererFunctions.m_pSetPositionCount = IL2CPP::ResolveCall(UNITY_LINERENDERER_SETPOSITIONCOUNT);
			LineRendererFunctions.m_pSetStartWidth = IL2CPP::ResolveCall(UNITY_LINERENDERER_SETSTARTWIDTH);
			LineRendererFunctions.m_pSetEndWidth = IL2CPP::ResolveCall(UNITY_LINERENDERER_SETENDWIDTH);
			LineRendererFunctions.m_pGetPosition = IL2CPP::ResolveCall(UNITY_LINERENDERER_GETPOSITION);

		}
	}
}