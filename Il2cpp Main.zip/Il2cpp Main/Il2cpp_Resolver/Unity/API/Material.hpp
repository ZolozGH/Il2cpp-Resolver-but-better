#pragma once
#include "../Unity_Classes.h"
// C+P Ready Template

namespace Unity
{
	struct SMaterial
	{
		void* m_pSetShader = nullptr;
		void* m_pSetColor = nullptr;
		void* m_pGetShader = nullptr;

	};
	extern SMaterial MaterialFunctions;

	class CMaterial : public IL2CPP::CClass
	{
	public:

		void SetShader(CShader* shader)
			{
				reinterpret_cast<void(UNITY_CALLING_CONVENTION)(void*, CShader*)>(MaterialFunctions.m_pSetShader)(this, shader);
			}


		//UnityEngine_Shader_o* GetShader()
		//{
			//return reinterpret_cast<UnityEngine_Shader_o*(UNITY_CALLING_CONVENTION)(void*)>(MaterialFunctions.m_pGetShader)(this);
		//}

		CShader* GetShader()
		{
			return reinterpret_cast<CShader*(UNITY_CALLING_CONVENTION)(void*)>(MaterialFunctions.m_pGetShader)(this);
		}
		
		void SetColor(Unity::Color color)
		{
			 reinterpret_cast<void(UNITY_CALLING_CONVENTION)(void*, Unity::Color&)>(MaterialFunctions.m_pSetColor)(this, color);
		}
		
	};

	namespace Material
	{
		void Initialize();
	}
}