#pragma once
#include "../Unity_Classes.h"
// C+P Ready Template

namespace Unity
{
	
	struct SRenderer
	{
		void* m_pGetMaterial = nullptr;
		void* m_pSetEnabled = nullptr;
	};
	extern SRenderer RendererFunctions;

	class CRenderer : public IL2CPP::CClass
	{
	public:
		CMaterial* GetMaterial()
		{
			return reinterpret_cast<CMaterial*(UNITY_CALLING_CONVENTION)(void*)>(RendererFunctions.m_pGetMaterial)(this);

		}
		
		void SetEnabled(bool t)
		{
			reinterpret_cast<void(UNITY_CALLING_CONVENTION)(void*, bool)>(MaterialFunctions.m_pSetColor)(this, t);
		}
		
		
	};




	namespace Renderer
	{

		void Initialize();
	}
}