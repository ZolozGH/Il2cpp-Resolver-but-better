#include "../../Includes.hpp"
// C+P Ready Template

namespace Unity
{
	SRenderer RendererFunctions;

	namespace Renderer
	{
		void Initialize()
		{
			IL2CPP::SystemTypeCache::Initializer::Add(UNITY_RENDERER_CLASS);
			RendererFunctions.m_pGetMaterial = IL2CPP::ResolveCall(UNITY_RENDERER_GETMATERIAL);
			RendererFunctions.m_pSetEnabled = IL2CPP::ResolveCall(UNITY_RENDERER_SETENABLED);
		}
		
	}
}