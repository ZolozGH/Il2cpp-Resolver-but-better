#include "../../Includes.hpp"
// C+P Ready Template

namespace Unity
{
	SMaterial MaterialFunctions;

	namespace Material
	{
		void Initialize()
		{
			IL2CPP::SystemTypeCache::Initializer::Add(UNITY_MATERIAL_CLASS);
			MaterialFunctions.m_pSetShader = IL2CPP::ResolveCall(UNITY_MATERIAL_SETSHADER);
			MaterialFunctions.m_pSetColor = IL2CPP::ResolveCall(UNITY_MATERIAL_SETCOLOR);
			MaterialFunctions.m_pGetShader = IL2CPP::ResolveCall(UNITY_MATERIAL_GETSHADER);

		}
	}
}