#include "../../Includes.hpp"
// C+P Ready Template

namespace Unity
{
	SShader ShaderFunctions;

	namespace Shader
	{
		void Initialize()
		{
			IL2CPP::SystemTypeCache::Initializer::Add(UNITY_SHADER_CLASS);
			ShaderFunctions.m_pFind = IL2CPP::ResolveCall(UNITY_SHADER_FIND);
			ShaderFunctions.FindShader = IL2CPP::Helper::SearchSignatureByClassAndFunctionName("UnityEngine.Shader", "Find");
		}

		Unity::CShader* Find(Unity::System_String* name) // it finds shader ... 
		{
			Unity::CShader* (UNITY_CALLING_CONVENTION t)(Unity::System_String*) = nullptr;
			return reinterpret_cast<decltype(t)>(ShaderFunctions.FindShader)(name);
		}
	}
}