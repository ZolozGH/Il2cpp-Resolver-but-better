#pragma once
#include <Unity/Includes.hpp>

namespace IL2CPP
{
	namespace Helper
	{
		Unity::CComponent* GetMonoBehaviour();
		uintptr_t SearchSignatureByClassAndFunctionName(const char* className, const char* functionName);
	}
}