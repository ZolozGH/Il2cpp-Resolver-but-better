#include "../Includes.hpp"

namespace IL2CPP
{
	namespace Helper
	{
		Unity::CComponent* GetMonoBehaviour()
		{
			Unity::il2cppArray<Unity::CGameObject*>* m_pObjects = Unity::Object::FindObjectsOfType<Unity::CGameObject>(UNITY_GAMEOBJECT_CLASS);
			for (uintptr_t u = 0U; m_pObjects->m_uMaxLength > u; ++u)
			{
				Unity::CGameObject* m_pObject = m_pObjects->operator[](static_cast<unsigned int>(u));
				if (!m_pObject) continue;

				Unity::CComponent* m_pMonoBehaviour = m_pObject->GetComponentByIndex(UNITY_MONOBEHAVIOUR_CLASS);
				if (m_pMonoBehaviour)
					return m_pMonoBehaviour;
			}

			return nullptr;
		}


		uintptr_t SearchSignatureByClassAndFunctionName(const char* className, const char* functionName) {
			Unity::il2cppClass* classPtr = IL2CPP::Class::Find(className);
			if (!classPtr) {
				printf("Class not found", className);
				return 0;
			}
			uintptr_t methodPtr = (uintptr_t)IL2CPP::Class::Utils::GetMethodPointer(classPtr, functionName);
			if (!methodPtr) {
				printf("Method not found", functionName);
				return 0;
			}
			printf("Class And Function Found. ", className, ".",functionName);
			return methodPtr;
		}
	}
}